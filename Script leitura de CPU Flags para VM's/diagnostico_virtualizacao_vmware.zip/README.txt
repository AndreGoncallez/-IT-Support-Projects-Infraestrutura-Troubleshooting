# Diagnóstico de Virtualização - VMware + EVE-NG

Este pacote contém um script PowerShell que verifica se sua máquina está pronta para executar virtualização aninhada no VMware Workstation, necessário para ambientes como o EVE-NG.

## Arquivo incluso

- `diagnostico_virtualizacao.ps1`: Script PowerShell para diagnóstico da virtualização VT-x e EPT.

## Como usar

1. Clique com o botão direito no arquivo `.ps1` e escolha **Executar com PowerShell como administrador**.
2. Observe a saída:
   - ✅ Virtualization Firmware
   - ✅ SLAT (EPT)
3. Use os resultados para confirmar se o sistema está pronto para virtualização aninhada.

## Requisitos

- Windows 10/11
- PowerShell com permissões administrativas
- Virtualização habilitada na BIOS

---

Desenvolvido para auxiliar a configuração de ambientes com EVE-NG.
